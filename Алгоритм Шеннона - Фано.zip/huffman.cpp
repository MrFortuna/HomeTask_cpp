#include "huffman.h"

Node::Node(char ch, double prob) : character(ch), probability(prob), left(nullptr), right(nullptr) {}

bool CompareNode::operator()(Node* lhs, Node* rhs) {
    return lhs->probability > rhs->probability;
}

void HuffmanCompression::buildHuffmanTree(std::vector<Node*>& nodes) {
    std::priority_queue<Node*, std::vector<Node*>, CompareNode> minHeap;
    for (auto node : nodes) {
        minHeap.push(node);
    }

    while (minHeap.size() > 1) {
        Node* left = minHeap.top(); minHeap.pop();
        Node* right = minHeap.top(); minHeap.pop();

        Node* internalNode = new Node('\0', left->probability + right->probability);
        internalNode->left = left;
        internalNode->right = right;

        minHeap.push(internalNode);
    }

    Node* root = minHeap.top();

    std::function<void(Node*, std::string)> generateCodes = [&](Node* node, std::string currentCode) {
        if (!node) return;
        if (node->character != '\0') {
            node->code = currentCode;
        }
        generateCodes(node->left, currentCode + "0");
        generateCodes(node->right, currentCode + "1");
    };

    generateCodes(root, "");
}

std::string HuffmanCompression::compressData(const std::string& data) {
    std::unordered_map<char, int> frequency;
    for (char ch : data) {
        frequency[ch]++;
    }

    std::vector<Node*> nodes;
    for (const auto& pair : frequency) {
        nodes.push_back(new Node(pair.first, static_cast<double>(pair.second) / data.size()));
    }

    buildHuffmanTree(nodes);

    std::unordered_map<char, std::string> huffmanCodes;
    for (auto node : nodes) {
        if (node->character != '\0') {
            huffmanCodes[node->character] = node->code;
        }
    }

    std::stringstream compressedText;
    for (char ch : data) {
        compressedText << huffmanCodes[ch];
    }

    std::ofstream compressedFile("compressed_text.txt");
    compressedFile << compressedText.str();
    compressedFile.close();

    std::ofstream dictFile("dict.txt");
    for (const auto& pair : huffmanCodes) {
        dictFile << "Symbol - " << pair.first << " :: Code - " << pair.second << "\n";
    }
    dictFile.close();

    return compressedText.str();
}