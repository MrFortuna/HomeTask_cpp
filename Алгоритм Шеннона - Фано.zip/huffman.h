#ifndef HUFFMAN_H
#define HUFFMAN_H

#include <iostream>
#include <fstream>
#include <vector>
#include <unordered_map>
#include <queue>
#include <string>
#include <sstream>
#include <functional>

struct Node {
    char character;
    double probability;
    std::string code;
    Node* left;
    Node* right;

    Node(char ch, double prob);
};

struct CompareNode {
    bool operator()(Node* lhs, Node* rhs);
};

class HuffmanCompression {
public:
    static void buildHuffmanTree(std::vector<Node*>& nodes);
    static std::string compressData(const std::string& data);
};

#endif // HUFFMAN_H