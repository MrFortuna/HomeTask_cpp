#include <iostream>
#include <fstream>
#include <sstream>
#include "huffman.h"

int main() {
    setlocale(LC_ALL, "English");

    int choice;
    std::cout << "Enter 1 to enter text manually, 2 to load from a file: ";
    std::cin >> choice;
    std::cin.ignore();

    if (choice == 1) {
        std::cout << "Enter the text to compress: ";
        std::string text;
        std::getline(std::cin, text);
        HuffmanCompression::compressData(text);
        std::cout << "Data saved to file compressed_text.txt" << std::endl;
        std::cout << "Dictionary saved to file dict.txt" << std::endl;
    } else if (choice == 2) {
        std::cout << "Specify the path to the file to load text: ";
        std::string filePath;
        std::getline(std::cin, filePath);
        std::ifstream file(filePath);
        if (!file.is_open()) {
            std::cerr << "File '" << filePath << "' not found." << std::endl;
            return 1;
        }
        std::stringstream buffer;
        buffer << file.rdbuf();
        std::string text = buffer.str();
        file.close();
        HuffmanCompression::compressData(text);
        std::cout << "Data saved to file compressed_text.txt" << std::endl;
        std::cout << "Dictionary saved to file dict.txt" << std::endl;
    } else {
        std::cerr << "Invalid option selected." << std::endl;
        return 1;
    }

    return 0;
}